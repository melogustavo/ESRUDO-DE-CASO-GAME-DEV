# Créditos

- Sprites tileset: (autor/link)
- Personagem: (autor/link)
- SFX: (autor/link)
- Música: (autor/link)
